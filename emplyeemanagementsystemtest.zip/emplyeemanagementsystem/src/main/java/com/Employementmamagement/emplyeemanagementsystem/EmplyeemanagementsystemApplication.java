package com.Employementmamagement.emplyeemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmplyeemanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmplyeemanagementsystemApplication.class, args);
	}

}
