package com.Employementmamagement.emplyeemanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmplyeemanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
